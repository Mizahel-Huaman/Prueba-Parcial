/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistema.de.registro;


/**
 *
 * @author Duoc
 */
import java.util.ArrayList;
import java.util.Scanner;

public class SistemaRegistro {
    static Scanner sc = new Scanner(System.in);
    static ArrayList<Estudiante> estudiantes = new ArrayList<>();
    static ArrayList<Docente> docentes = new ArrayList<>();
    static ArrayList<Asignatura> Asignaturas = new ArrayList<>();

    public static void main(String[] args) {
        int opcion;
        do {
            System.out.println("\n----- Sistema de Registro ----");
            System.out.println("1. Ingresar Estudiante");
            System.out.println("2. Ingresar Docente");
            System.out.println("3. Ingresar Asignatura");
            System.out.println("4. Mostrar Asignatura");
            System.out.println("5. Calcular resultado.");
            System.out.println("6. Salir");
            System.out.println("Seleccione una opcion: ");
            opcion = sc.nextInt();
            sc.nextLine();
            
            switch(opcion) {
                case 1 -> ingresarEstudiante();
                case 2 -> ingresarDocente();
                case 3 -> ingresarAsignatura();
                case 4 -> mostrarAsignaturas();   
                case 5 -> calcularResultados();
                case 6 -> System.out.println("Saliendo...");
                default -> System.out.println("Opcion innvalida");
       
            }
        } while(opcion != 6);

    }
   
    static void ingresarEstudiante() {
        System.out.println("RUT: ");
        String rut = sc.nextLine();
        System.out.println("Nombre: ");
        String nombre = sc.nextLine();
        System.out.println("Edad: ");
        int edad = sc.nextInt(); sc.nextLine();
       
        estudiantes.add(new Estudiante(rut, nombre, edad));
        System.out.println("Estudiante registrado");
    }
    
    static void ingresarDocente() {
        System.out.println("RUT: ");
        String rut = sc.nextLine();
        System.out.println("Nombre: ");
        String nombre = sc.nextLine();
        
        docentes.add(new Docente(rut, nombre));
        System.out.println("Docente registrado");
    }
    
    static void ingresarAsignatura() {
        if(estudiantes.isEmpty() || docentes.isEmpty()) {
            System.out.println("debe registrar al menos 1 estudiante y 1 docente");
            return;
        }
        System.out.println("Codigo: ");
        String codigo = sc.nextLine();
        System.out.println("Nombre: ");
        String nombre = sc.nextLine();
        
        System.out.println("Seleccione estudiante:");
        for(int i=0; i<estudiantes.size(); i++) {
            System.out.println(i+1 + ", " + estudiantes.get(i)); 
        }
        int e = sc.nextInt(); sc.nextLine();

        System.out.println("Seleccione docente:");
        for(int i=0; i<docentes.size(); i++) {
        System.out.println((i+1) + ". " + docentes.get(i));
        }
        
        int d = sc.nextInt(); sc.nextLine();

        System.out.print("Nota1: ");
        double n1 = sc.nextDouble();
        System.out.print("Nota2: ");
        double n2 = sc.nextDouble();
        System.out.print("Nota3: ");
        double n3 = sc.nextDouble();
        sc.nextLine();

        Asignaturas.add(new Asignatura(codigo, nombre, estudiantes.get(e-1), docentes.get(d-1), n1, n2, n3));
        System.out.println("Asignatura registrada");
    }
    static void mostrarAsignaturas() {
       if (Asignaturas.isEmpty()) {
           System.out.println("No hay asignaturas registradas.");
           return;
        }
        for(Asignatura a : Asignaturas) {
            System.out.println("\n" + a);
        }
    }

    static void calcularResultados() {
       if (Asignaturas.isEmpty()) {
           System.out.println("No hay asignaturas registradas.");
           return;
       }

       for (Asignatura a : Asignaturas) {
            System.out.println("\n--- Resultados ---");
            System.out.println(a);

       if (a.estaEximido()) {
           System.out.println("El estudiante está EXIMIDO ✅");
        } else {
           System.out.print("Ingrese nota de examen: ");
           double examen = sc.nextDouble();
           sc.nextLine();
           System.out.println(a.calcularNotaFinal(examen));
        }
    }
  }
}
              

       
       
       
       
