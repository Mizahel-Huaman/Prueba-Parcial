/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema.de.registro;

/**
 *
 * @author Duoc
 */
public class Estudiante {
    private String rut;
    private String nombre;
    private int edad;
           
    public Estudiante(String rut, String nombre, int edad) {
        this.rut = rut;
        this.nombre = nombre;
        this.edad = edad;
        
    }
    
    public String getRut() { return rut; }
    public String getNombre() { return nombre; }
    public int getEdad() { return edad; }
    
    @Override
    public String toString() {
        return "RUT: " + rut + ", Nombre: " + nombre + ", Edad: " + edad;
        
    }
    
}

