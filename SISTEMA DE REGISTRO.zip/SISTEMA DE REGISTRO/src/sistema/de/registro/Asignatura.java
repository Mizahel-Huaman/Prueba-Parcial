/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema.de.registro;

/**
 *
 * @author Duoc
 */
public class Asignatura {
    private String codigo;
    private String nombre;
    private Estudiante estudiante;
    private Docente docente;
    private double nota1, nota2, nota3;
    
    public Asignatura(String codigo, String nombre, Estudiante estudiante, Docente docente, double nota1, double nota2, double nota3) {
        this.codigo = codigo; 
        this.nombre = nombre;
        this.estudiante = estudiante;
        this.docente = docente;
        this.nota1 = nota1; 
        this.nota2 = nota2;
        this.nota3 = nota3;
        
    }
    
    public double calcularNotaPresentacion() {
        return (nota1 * 0.4) + (nota2 * 0.4) + (nota3 * 0.2);
    
    }
    
    public boolean estaEximido() {
        return calcularNotaPresentacion() >= 5.5;
    }

    public String calcularNotaFinal(double examen) {
        double presentacion = calcularNotaPresentacion();
        double notaFinal = (presentacion * 0.7) + (examen * 0.3);
        if (notaFinal >= 4.5) {
            return "Aprobado con nota final: " + String.format("%.2f", notaFinal);
        } else {
            return "❌ REPROBADO con nota final: " + String.format("%.2f", notaFinal);
        }
    }
    @Override
    public String toString() {
       return "Asignatura: " + nombre + " (" + codigo + ")\n" +
              "Estudiante: " + estudiante.getNombre() + "\n" +
              "Docente: " + docente.getNombre() + "\n" +
              "Notas: " + nota1 + ", " + nota2 + ", " + nota3 + "\n" +
              "Nota Presentación: " + String.format("%.2f", calcularNotaPresentacion()) +
              (estaEximido() ? " (Eximido)" : "");
    }
}


       




