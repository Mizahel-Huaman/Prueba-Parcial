/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema.de.registro;

/**
 *
 * @author Duoc
 */
public class Docente {
    private String rut;
    private String nombre;
    
    public Docente(String rut, String nombre) {
        this.rut = rut;
        this.nombre = nombre;
        
    }
    
    public String getRut() { return rut; }
    public String getNombre() { return nombre; }
    
    @Override
    public String toString() {
        return "RUT: " + rut + ",Nombre: " + nombre;
    }
    
}


